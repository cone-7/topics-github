function index(props) {
    return (<div>
        <input type="text"/>
    </div>);
}


export default index;